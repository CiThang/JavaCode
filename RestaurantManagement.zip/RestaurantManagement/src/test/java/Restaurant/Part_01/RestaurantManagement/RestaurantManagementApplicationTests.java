package Restaurant.Part_01.RestaurantManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
