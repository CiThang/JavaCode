package com.SpringPro.SpringPro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProApplicationTests {

	@Test
	void contextLoads() {
	}

}
