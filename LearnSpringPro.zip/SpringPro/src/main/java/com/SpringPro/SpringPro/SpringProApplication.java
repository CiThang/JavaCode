package com.SpringPro.SpringPro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringProApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringProApplication.class, args);
	}

}
