package SpringBootHibernateJavaFx.CafeTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CafeTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
